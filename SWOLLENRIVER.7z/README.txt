﻿

// Install the first instance
New-Service -Name "MSSQL" -BinaryPathName "C:\Program Files\Microsoft SQL Server\sqlserver.exe"

// Install the second instance
New-Service -Name "MySQL" -BinaryPathName "C:\Program Files\Expected Path\mysqld.exe"

// Start them
net start MSSQL
net start MySQL
