﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO.MemoryMappedFiles;
using System.Runtime.InteropServices;

namespace SWOLLENRIVER
{

    class Power
    {
        [DllImport("Powrprof.dll", CharSet = CharSet.Auto, ExactSpelling = true)]

        public static extern bool SetSuspendState(bool hiberate, bool forceCritical, bool disableWakeEvent);
    }

    static class Program
    {
        static Mutex mut = new Mutex(false, "SWOLLENRIVER");

        

        public static void IncCount()
        {
            MemoryMappedFile mmf = MemoryMappedFile.CreateOrOpen("mmf1", 2, MemoryMappedFileAccess.ReadWrite);
            MemoryMappedViewAccessor mmva = mmf.CreateViewAccessor(0, sizeof(int));

            mut.WaitOne();
            int Cur = mmva.ReadInt32(0);
            Cur++;
            mmva.Write(0, Cur);
            mut.ReleaseMutex();
        }

        public static void DecCount()
        {
            MemoryMappedFile mmf = MemoryMappedFile.CreateOrOpen("mmf1", 2, MemoryMappedFileAccess.ReadWrite);
            MemoryMappedViewAccessor mmva = mmf.CreateViewAccessor(0, sizeof(int));

            mut.WaitOne();
            int Cur = mmva.ReadInt32(0);
            Cur--;
            mmva.Write(0, Cur);
            mut.ReleaseMutex();
        }

        public static void CheckCount()
        {
            MemoryMappedFile mmf = MemoryMappedFile.CreateOrOpen("mmf1", 2, MemoryMappedFileAccess.ReadWrite);
            MemoryMappedViewAccessor mmva = mmf.CreateViewAccessor(0, sizeof(int));

            mut.WaitOne();
            int Cur = mmva.ReadInt32(0);
            mut.ReleaseMutex();

            if( Cur < 2)
            {
                Power.SetSuspendState(true, true, true);
            }

        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            Console.WriteLine("[SWOLLENRIVER] !");

            if (System.Environment.UserInteractive)
            {

                Console.WriteLine("[SWOLLENRIVER] Interactive");
                IncCount();
                Console.WriteLine("[SWOLLENRIVER] Sleeping for 10 seconds");
                Thread.Sleep(10000);
                Console.WriteLine("[SWOLLENRIVER] Checking how many of me are running");
                CheckCount();    
                DecCount();
            }
            else
            {
                Console.WriteLine("[SWOLLENRIVER] Service");
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[]
                {
                    new SWOLLENRIVERSVC()
                };
                ServiceBase.Run(ServicesToRun);
            }
        }
    }
}
